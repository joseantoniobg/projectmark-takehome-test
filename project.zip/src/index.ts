import express, { Express, Request, Response } from "express";
import { validateDto } from "./infra/middleware/validation.middleware";
import { UserDto } from "./app/dto/user.dto";

const app: Express = express();

const port = process.env.PORT || 3000;

app.get("/", (req: Request, res: Response) => {
  res.send("Hello, this is your Express + TypeScript server!");
});

//app.post("/users", validateDto(UserDto), userController.create);

app.listen(port, () => {
  console.log(`[server]: Server is running at http://localhost:${port}`);
});
