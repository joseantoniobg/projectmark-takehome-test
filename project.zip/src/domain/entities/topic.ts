import { generateUuid } from "../helpers/functions.helpers";
import { Resource } from "./resource";
import { User } from "./user";

export class Topic {
  id: string;
  name: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  version: number;
  resources: Resource[];
  user: User;
  parentTopic?: Topic;

  constructor(
    name: string,
    content: string,
    version: number,
    resources: Resource[],
    user: User,
    parentTopic?: Topic,
    id?: string
  ) {
    this.id = id ?? generateUuid();
    this.name = name;
    this.content = content;
    this.version = version;
    this.resources = resources;
    this.user = user;
    this.parentTopic = parentTopic;
    this.createdAt = new Date();
    this.updatedAt = new Date();
  }
}
