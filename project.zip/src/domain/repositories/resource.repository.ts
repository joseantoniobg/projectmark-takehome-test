import { Resource } from "../entities/resource";

export interface ResourceRepository {
  create(resource: Resource): Promise<Resource>;
}
