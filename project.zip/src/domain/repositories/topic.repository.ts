import { Topic } from "../entities/topic";

export interface TopicRepository {
  create(topic: Topic): Promise<Topic>;
  update(topic: Topic): Promise<Topic>;
  getOne(id: string, version?: number): Promise<Topic | undefined>;
  getOneWithChildren(id: string): Promise<Topic>;
  findLinkBetweenTwoTopics(id1: string, id2: string): Promise<Topic[]>;
}
