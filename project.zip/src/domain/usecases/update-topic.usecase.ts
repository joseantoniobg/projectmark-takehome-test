import { Topic } from "../entities/topic";
import { RoleEnum } from "../enums/role.enum";
import { TopicModel } from "../models/topic.model";
import { TopicRepository } from "../repositories/topic.repository";
import { UserRepository } from "../repositories/user.repository";
import { CreateTopicUseCase } from "./create-topic.usecase";

export class UpdateTopicUseCase {
  constructor(
    private readonly userRepository: UserRepository,
    private readonly topicRepository: TopicRepository,
    private readonly createTopicUseCase: CreateTopicUseCase
  ) {}

  async execute(id: string, topic: TopicModel): Promise<Topic> {
    const originalTopic = await this.topicRepository.getOne(id);

    if (!originalTopic) {
      throw new Error("Topic not found");
    }

    const user = await this.userRepository.find(topic.userId);

    if (!user) {
      throw new Error("User not found");
    }

    if (originalTopic?.user.id !== user.id && user.role !== RoleEnum.ADMIN) {
      throw new Error("Only admins or the topic's author can update the topic");
    }

    const version = originalTopic.version + 1;

    return this.createTopicUseCase.execute(
      topic,
      originalTopic.id,
      user,
      version
    );
  }
}
