import { User } from "../entities/user";
import { RoleEnum } from "../enums/role.enum";
import { hasInformation, isValidEnumItem } from "../helpers/functions.helpers";
import { CreateUserModel } from "../models/create-user.model";
import { UserRepository } from "../repositories/user.repository";

export class CreateUserUseCase {
  constructor(private readonly userRepository: UserRepository) {}

  async execute(user: CreateUserModel): Promise<User> {
    if (!hasInformation(user.name)) {
      throw new Error("Username must by informed");
    }

    if (!hasInformation(user.email)) {
      throw new Error("User email must be informed");
    }

    if (!isValidEnumItem(RoleEnum, user.role)) {
      throw new Error("Invalid User Role");
    }

    const userWithSameEmail = await this.userRepository.findByEmail(user.email);

    if (userWithSameEmail) {
      throw new Error("E-mail already used");
    }

    const userEntity = new User(user.name, user.email, user.role);

    return await this.userRepository.create(userEntity);
  }
}
