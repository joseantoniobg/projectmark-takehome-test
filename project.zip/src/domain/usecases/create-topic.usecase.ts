import { Topic } from "../entities/topic";
import { RoleEnum } from "../enums/role.enum";
import { hasInformation, isValidEnumItem } from "../helpers/functions.helpers";
import { TopicModel } from "../models/topic.model";
import { TopicRepository } from "../repositories/topic.repository";
import { UserRepository } from "../repositories/user.repository";
import { ResourceTypeEnum } from "../enums/resource-type.enum";
import { Resource } from "../entities/resource";
import { User } from "../entities/user";

export class CreateTopicUseCase {
  constructor(
    private readonly topicRepository: TopicRepository,
    private readonly userRepository: UserRepository
  ) {}
  async execute(
    topic: TopicModel,
    id?: string,
    user?: User,
    version?: number
  ): Promise<Topic> {
    if (!hasInformation(topic.name)) {
      throw new Error("Topic name must be informed");
    }

    if (!hasInformation(topic.content)) {
      throw new Error("Topic must have some content");
    }

    if (!user) {
      user = await this.userRepository.find(topic.userId);
    }

    if (!user) {
      throw new Error("User not found");
    }

    if (user.role === RoleEnum.VIEWER) {
      throw new Error("Viewers can not create topics");
    }

    let parentTopic: Topic | undefined;

    if (topic.parentTopicId) {
      parentTopic = await this.topicRepository.getOne(topic.parentTopicId);

      if (!parentTopic) {
        throw new Error("Parent Topic not found");
      }
    }

    for (const resource of topic.resources) {
      if (!hasInformation(resource.description)) {
        throw new Error("Resource description is needed");
      }

      if (!hasInformation(resource.url)) {
        throw new Error("Resource URL is needed");
      }

      if (!isValidEnumItem(ResourceTypeEnum, resource.type)) {
        throw new Error("Invalid resource type");
      }
    }

    const resourceEntities = topic.resources.map(
      (resource) =>
        new Resource(
          resource.url,
          resource.description,
          resource.type,
          resource.id
        )
    );

    const topicEntity = new Topic(
      topic.name,
      topic.content,
      version ?? 1,
      resourceEntities,
      user,
      parentTopic,
      id
    );

    return await this.topicRepository.create(topicEntity);
  }
}
