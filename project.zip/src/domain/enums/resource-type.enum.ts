export enum ResourceTypeEnum {
  ARTICLE = "article",
  VIDEO = "video",
  DOCUMENT = "document",
  AUDIO = "audio",
}
