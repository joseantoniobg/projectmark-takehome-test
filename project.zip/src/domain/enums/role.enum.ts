export enum RoleEnum {
  ADMIN = "Admin",
  EDITOR = "Editor",
  VIEWER = "Viewer",
}
