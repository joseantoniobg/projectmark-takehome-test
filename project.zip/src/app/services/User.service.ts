import { inject, injectable } from "tsyringe";
import { CreateUserUseCase } from "../../domain/usecases/create-user.usecase";
import { UserDto } from "../dto/user.dto";
import { User } from "../../infra/typeorm/entities/user.entity";

@injectable()
export class UserService {
  constructor(
    @inject("CreateUserUseCase")
    private readonly createUserUseCase: CreateUserUseCase
  ) {}

  async createUser(user: UserDto): Promise<User> {
    return await this.createUserUseCase.execute(user);
  }
}
