import { container } from "tsyringe";
import { UserService } from "../services/User.service";
import { UserDto } from "../dto/user.dto";

export class UserController {
  contructor() {}

  async create(req: Request, res: Response): Promise<Response> {
    const createUserDto: UserDto = req.body;

    try {
      const userService = await container.resolve(UserService);
      const newUser = await userService.createUser(createUserDto);
    } catch (e) {}
  }
}
