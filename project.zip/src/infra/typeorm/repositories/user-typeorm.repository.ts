import { CreateUserModel } from "../../../domain/models/create-user.model";
import { UserRepository } from "../../../domain/repositories/user.repository";
import { User } from "../entities/user.entity";
import { SqliteDataSource } from "../sqlite-data-source";

export const UserTypeormRepository: UserRepository =
  SqliteDataSource.getRepository(User).extend({
    async create(user: CreateUserModel): Promise<User> {
      return await this.save(user);
    },
    findByEmail: function (email: string): Promise<User | undefined> {
      throw new Error("Function not implemented.");
    },
    find: function (id: string): Promise<User | undefined> {
      throw new Error("Function not implemented.");
    },
  });
