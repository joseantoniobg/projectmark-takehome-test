import { TopicRepository } from "../../../domain/repositories/topic.repository";
import { Topic } from "../entities/topic.entity";
import { SqliteDataSource } from "../sqlite-data-source";

export const TopicTypeormRepository: TopicRepository =
  SqliteDataSource.getRepository(Topic).extend({
    async create(topic: Topic): Promise<Topic> {
      return await this.save(topic);
    },
    update: function (topic: Topic): Promise<Topic> {
      throw new Error("Function not implemented.");
    },
    getOne: function (
      id: string,
      version?: number
    ): Promise<Topic | undefined> {
      throw new Error("Function not implemented.");
    },
    getOneWithChildren: function (id: string): Promise<Topic> {
      throw new Error("Function not implemented.");
    },
    findLinkBetweenTwoTopics: function (
      id1: string,
      id2: string
    ): Promise<Topic[]> {
      throw new Error("Function not implemented.");
    },
  });
