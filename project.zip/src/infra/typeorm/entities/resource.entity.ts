import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
} from "typeorm";
import { ResourceTypeEnum } from "../../../domain/enums/resource-type.enum";
import { Topic } from "./topic.entity";

@Entity("resource")
export class Resource {
  @PrimaryColumn("uuid")
  id: string;

  @Column({ name: "topic_id", type: "uuid" })
  topicId: string;

  @ManyToOne(() => Topic, (topic) => topic.resources)
  @JoinColumn({ name: "topicId", referencedColumnName: "id" })
  topic: Topic;

  @Column({ type: "text" })
  url: string;

  @Column({ type: "varchar", length: 100 })
  description: string;

  @Column({ type: "enum", enum: ResourceTypeEnum })
  type: ResourceTypeEnum;

  @Column({ type: "timestamp" })
  createdAt: Date;

  @Column({ type: "timestamp" })
  updatedAt: Date;
}
