import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
} from "typeorm";
import { Resource } from "./resource.entity";
import { User } from "./user.entity";

@Entity("topic")
export class Topic {
  @PrimaryColumn("uuid")
  id: string;

  @Column({ type: "varchar", length: 200 })
  name: string;

  @Column({ type: "text" })
  content: string;

  @PrimaryColumn({ type: "int" })
  version: number;

  @Column({ name: "parent_topic_id", type: "uuid", nullable: true })
  parentTopicId?: string;

  @ManyToOne(() => Topic, (topic) => topic.children, {
    nullable: true,
    onDelete: "NO ACTION",
  })
  @JoinColumn({ name: "parentTopicId", referencedColumnName: "id" })
  parentTopic?: Topic;

  @Column({ name: "user_id", type: "uuid" })
  userId: string;

  @ManyToOne(() => User, (user) => user.id)
  @JoinColumn({ name: "userId", referencedColumnName: "id" })
  user: User;

  @OneToMany(() => Topic, (topic) => topic.parentTopic)
  children: Topic[];

  @OneToMany(() => Resource, (resource) => resource.topic)
  resources: Resource[];

  @Column({ type: "timestamp" })
  createdAt: Date;

  @Column({ type: "timestamp" })
  updatedAt: Date;
}
